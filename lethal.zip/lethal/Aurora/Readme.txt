﻿Cheat Happens Aurora
www.cheathappens.com

DOCUMENTATION


REQUIREMENTS
------------
Windows 10 19303 (also known as 19H1 or build 10.0.18362) or greater
Internet connection, or an offline key
Full HD resolution


Installation
------------
Aurora is a portable application. Unzip everything to a folder of your choice. Then launch Aurora by double clicking on Aurora.exe. DO NOT LAUNCH AURORA WITHOUT EXTRACTING TO DISK!


OFFLINE MODE
------------
In order to use the offline mode and to download offline trainers you must first request an offline key. Offline keys are not available for everyone and they are limited. Click on your avatar at the top right to open app settings. Scroll down until the offline key section. Read the statement, tick the checkbox and click the button to request an offline key. You will get a notification if it was successful or not. On success the offline key is stored in Aurora's directory. You can now download offline trainers by clicking on the 'Save' icon next to 'Use trainer' button. Favorite trainers are automatically downloaded every time you open them, unless there is an offline copy created within last 12 hours already.

Note: To enter offline mode you must be offline. Please see Q & A below for troubleshooting. You have to restart Aurora to enter 'online mode'.

Note: There is a limit on how many offline trainers you can download per week. So use it rarely / wisely. Your offline key amount will not decrease when you request an offline key again and your hardware has not changed.


SETTINGS
------------
To open the setting menu click on the avatar icon at the top right.

Note: If you hold down SHIFT key while opening Aurora you can choose to start with default settings.


STANDALONE TRAINERS
------------
Click on your avatar at the top right first to open the app settings. Add your standalone trainers directories, then restart Aurora. You can find your standalone trainers on the 'Trainers' page under 'Standalone / Offline Trainers' tab. You can add standalone trainers to your favorite list if Aurora can read the trainer information


FAVORITES
------------
You can add a trainer to your favorites. The trainer will then appear at the left menu for easier access. To add a trainer to your favorites, open the trainer and click on the heart icon at the top right. You can reorder your favorite items by using drag and drop.


Q & A
------------
Q: The window is outside of my monitor or not visible. How do I get it back?
A: Make sure the window has keyboard focus, then press Ctrl+Alt+Shift+R. Alternatively open task manager find Aurora window and right click on it and choose 'Maximize'. Then resize the window back to your preferences.

Q: I am offline but Aurora says I am online
A: Wait until the system recognizes you are offline. You can force this by disable (and re-enable) your internet network adapter in Windows.

Q: How do I get back the screen where I can choose the game distribution?
A: Keep holding down your left CTRL button on your keyboard while you click on the trainer (preferrably from 'Trainers' page)


Command line arguments
------------
-resetwindowposition
Resets the stored window positions. Useful if the window spawned outside of your screen
-checkconnection:
Test the connection to our and google server and provides you the results


DISCLAIMER / PRIVACY
--------------------
For information on what is collected and/or sent to Cheat Happens by Aurora please review our Privacy Policy at https://www.cheathappens.com/privacypolicy.asp. 

Cheat Happens is a trademark of Dingo WebWorks, LLC
Aurora (C) 2022